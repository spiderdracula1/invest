package com.example.bookshelf.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.bookshelf.R
import com.example.bookshelf.model.Book
import com.example.bookshelf.databinding.ItemShelfBinding

class ShelfAdapter(
    private val shelves: List<List<Book>>, // Список полок (каждая полка - список до 3 книг)
    private val onItemClick: (Book) -> Unit
) : RecyclerView.Adapter<ShelfAdapter.ShelfViewHolder>() {

    inner class ShelfViewHolder(val binding: ItemShelfBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShelfViewHolder {
        val binding = ItemShelfBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ShelfViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ShelfViewHolder, position: Int) {
        val currentShelfBooks = shelves[position] // Берем группу книг для этой полки

        // Настраиваем слот 1
        setupSlot(holder.binding.slot1.root as ViewGroup, currentShelfBooks.getOrNull(0))
        // Настраиваем слот 2
        setupSlot(holder.binding.slot2.root as ViewGroup, currentShelfBooks.getOrNull(1))
        // Настраиваем слот 3
        setupSlot(holder.binding.slot3.root as ViewGroup, currentShelfBooks.getOrNull(2))
    }

    private fun setupSlot(container: ViewGroup, book: Book?) {
        val imageView = container.findViewById<ImageView>(R.id.ivBookCover)

        if (book != null) {
            container.visibility = View.VISIBLE
            Glide.with(container.context)
                .load(book.coverImage)
                .placeholder(R.drawable.ic_book_placeholder)
                .into(imageView)

            container.setOnClickListener { onItemClick(book) }
        } else {
            // Если книги нет (например, на последней полке всего 2 книги)
            container.visibility = View.INVISIBLE
        }
    }

    override fun getItemCount(): Int = shelves.size
}