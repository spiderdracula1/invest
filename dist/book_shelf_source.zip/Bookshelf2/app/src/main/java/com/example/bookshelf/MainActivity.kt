package com.example.bookshelf

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.example.bookshelf.adapter.ViewPagerAdapter
import com.example.bookshelf.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewPager: ViewPager2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Это заставляет приложение рисовать контент ПОД статус-баром
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewPager = binding.viewPager
        viewPager.adapter = ViewPagerAdapter(this)
        viewPager.offscreenPageLimit = 1

        TabLayoutMediator(binding.tabLayout, viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> "НЕДАВНИЕ"
                1 -> "МОИ КНИГИ"
                2 -> "МАГАЗИН"
                else -> ""
            }
        }.attach()

        binding.fabSearch.setOnClickListener {
            Toast.makeText(this, "🔍 Поиск", Toast.LENGTH_SHORT).show()
        }
    }
}