package com.example.bookshelf.ui.shelf

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.bookshelf.R
import com.example.bookshelf.adapter.ShelfAdapter
import com.example.bookshelf.databinding.FragmentShelfBinding
import com.example.bookshelf.model.Book

class ShelfFragment : Fragment() {

    private var _binding: FragmentShelfBinding? = null
    private val binding get() = _binding!!

    // Получаем категорию, переданную из ViewPagerAdapter
    private val category: String by lazy { arguments?.getString(ARG_CATEGORY) ?: "recent" }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentShelfBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupShelves()
    }

    private fun setupShelves() {
        // 1. Создаем плоский список всех книг
        val allBooks = listOf(
            Book(1, "Беглецы и бродяги", "Автор 1", R.drawable.manifesto, "fiction"),
            Book(2, "Бегущая с волками", "Автор 2", R.drawable.ic_book_placeholder, "fiction"),
            Book(3, "Ветер в ивах", "Автор 3", R.drawable.ic_book_placeholder, "fiction"),
            Book(4, "Память", "Автор 4", R.drawable.ic_book_placeholder, "nonfiction"),
            Book(5, "Запомни быстро", "Автор 5", R.drawable.ic_book_placeholder, "selfhelp"),
            Book(6, "Бездушный", "Автор 6", R.drawable.ic_book_placeholder, "fantasy"),
            Book(7, "Безлюдные земли", "Автор 7", R.drawable.ic_book_placeholder, "fantasy")
        )

        // 2. Делим список на группы по 3 книги (для полок)
        val shelvesData = allBooks.chunked(3)

        // 3. Настраиваем адаптер полок
        val adapter = ShelfAdapter(shelvesData) { book ->
            Toast.makeText(requireContext(), "📚 ${book.title}", Toast.LENGTH_SHORT).show()
        }

        binding.recyclerViewBooks.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_CATEGORY = "category"

        // ✅ ВОТ ЭТА ЧАСТЬ ОТСУТСТВОВАЛА (Именно её искал адаптер)
        fun newInstance(category: String): ShelfFragment {
            val fragment = ShelfFragment()
            val args = Bundle()
            args.putString(ARG_CATEGORY, category)
            fragment.arguments = args
            return fragment
        }
    }
}