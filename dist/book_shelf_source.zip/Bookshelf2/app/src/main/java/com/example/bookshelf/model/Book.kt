package com.example.bookshelf.model

data class Book(
    val id: Int,
    val title: String,
    val author: String,
    val coverImage: Int, // Resource ID для локальных изображений
    val category: String
)