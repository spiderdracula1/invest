package com.example.bookshelf.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.bookshelf.ui.shelf.ShelfFragment

class ViewPagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {

    // Три вкладки: недавние, мои книги, магазин
    private val fragmentCategories = listOf("recent", "my_books", "store")

    override fun getItemCount(): Int = fragmentCategories.size

    override fun createFragment(position: Int): Fragment {
        return ShelfFragment.newInstance(fragmentCategories[position])
    }
}