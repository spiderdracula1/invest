plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.bookshelf"
    compileSdk {
        version = release(36) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        applicationId = "com.example.bookshelf"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    // 2. Включаем ViewBinding, чтобы работал код binding.root из туториала
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)

    // 3. Добавляем RecyclerView для списка книг
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // 4. Добавляем Glide для загрузки картинок обложек
    implementation("com.github.bumptech.glide:glide:4.16.0")

    // 5. ConstraintLayout (полезно для сложных экранов)
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    implementation("androidx.viewpager2:viewpager2:1.1.0-beta02")
    implementation("androidx.core:core-ktx:1.12.0") // ✅ Нужен для ViewCompat
}